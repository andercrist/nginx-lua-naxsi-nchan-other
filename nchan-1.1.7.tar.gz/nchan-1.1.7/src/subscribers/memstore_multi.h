#define NCHAN_SUB_MULTI_NOTIFY_ADDSUB 0
subscriber_t *memstore_multi_subscriber_create(memstore_channel_head_t *chanhead, uint8_t n);
